//features int[-32,31] A;
features int[-32,31] B;

int main() {
  int x,y; 
  while (x >= 0) {  
    x = x - B;
  }
  return 0;
}